const path = require('path')
const { VueLoaderPlugin } = require('vue-loader')
 
module.exports = {
    entry: {
        index: path.join(__dirname, "/src/index.js") 
    },
    output: {
        path: path.join(__dirname, "/dist"), 
        publicPath: '/dist/',  
        filename: "vueActivityCalendar.js", 
        libraryTarget: 'umd' 
    },
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.m?js$/,
                exclude: /node_modules|vue\/dist|vue-router\/|vue-loader\/|vue-hot-reload-api\//,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            }
        ]
    },
    plugins: [
        new VueLoaderPlugin()
    ]
}