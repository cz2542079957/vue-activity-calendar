import Page from "./components/ActivityCalendar.vue";

Page.install = Vue => Vue.components(Page.name, Page);

export default Page;